import os
os.environ['PYTHONHASHSEED'] = '0'
os.environ['KERAS_BACKEND'] = 'tensorflow'
#os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import random
random.seed(0)
import numpy as np
np.random.seed(0)
import tensorflow as tf
from tensorflow import set_random_seed
set_random_seed(1)
from keras import backend as K

import pandas as pd
import copy
from ENDE import Encoder
from keras.models import load_model
import pickle
import sys
import math

#################################################
ntw="THS"#"NYC"#"THS"
ntwD={"NYC":55, "THS":25}
Pwnd=int(sys.argv[1])
op="output/"+ntw+"/"
Hwnd=int(sys.argv[1])
Pwnd=int(sys.argv[2])
dim=int(sys.argv[3])
#################################################changes above
if not os.path.exists(op):
	os.makedirs(op)


#rounding odt
def rnd(x):
	if isinstance(x, list):
		N=len(x)
	else:
		N=x.shape[0]
	for i in range(N):
		a=x[i]
		a[~np.isfinite(a)]=0
		a[a<=0]=0
		a=np.around(a)
		x[i]=a
	x=x.astype(int)
	return x

#desensitize odt with weekly historic values on hours
def minMax(odt, ts, mnF, mxF):
	t, n, m=odt.shape[0], odt.shape[1], odt.shape[2]
	mn=odt[:ts].min(axis=0); mx=odt[:ts].max(axis=0); dmx=copy.deepcopy(mx); dmx[dmx==0]=1
	odt=(odt-mn)/(dmx-mn)
	np.save(mnF, mn)
	np.save(mxF, mx)
	return odt, mn, mx##rescaling is just simple as res*(mx-mn)+mn

def getFiles_n_Model():
	##reading original files
	#data_path="../../../FROC/Data/"+ntw+"/"
	data_path="../../../FROC/Data/"+ntw+"/"
	fl=data_path+"activeODT"+ntw+"3m_30.npy"
	odt=np.load(fl)
	odt[~np.isfinite(odt)]=0

	global Hwnd; global Pwnd; global dim
	#arguments and obtaining a model
	batch=32; N=Hwnd; n=ntwD[ntw]; f=2; d_dim=dim; k_depth=2; pwnd=Pwnd; T_k=40; batch_size=32
	samples=odt.shape[0]-(N+pwnd)+1
	kwargs={"batch":batch, "A":(N, n, n), "X":(N, n, f), "d_dim":d_dim, "k_depth":k_depth, "pwnd":pwnd, "T_k":T_k}
	en=Encoder()
	model=en.enDe(**kwargs)	
	
	odt, mn, mx=minMax(odt, int(0.8*samples), op+"mn.npy", op+"mx.npy")
	#get train-test X Y
	x=np.zeros((samples, N, n, n))
	y=np.zeros((samples, pwnd, n, n))
	fs=np.zeros((samples, N, n, f))

	for i in range(samples):
		x[i, ::]=odt[i:i+N, ::]
		fs[i, ::]=np.stack((odt[i:i+N, ::].sum(axis=1), odt[i:i+N, ::].sum(axis=2)), axis=2)
		y[i, ::]=odt[i+N:i+N+pwnd, ::]		

	trN=int(0.8*samples); trN=trN-trN%batch_size; tsN=samples-trN
	xTs=x[-tsN:]; fsTs=fs[-tsN:]; yTs=y[-tsN:]; tsN=tsN-tsN%batch_size
	xTs=x[:tsN]; fsTs=fs[:tsN]; yTs=y[:tsN]
	vN=int(0.1*trN/batch_size)*batch_size
	xV=x[-vN:]; fsV=fs[-vN:]; yV=y[-vN:]
	trN=trN-vN
	xTr=x[:trN]; fsTr=fs[:trN]; yTr=y[:trN]

	#print (odt.shape)
	#print (xTr.shape, yTr.shape, fsTr.shape, xV.shape, yV.shape, fsV.shape, xTs.shape, fsTs.shape, yTs.shape)#; input ("enter")

	return xTr, fsTr, yTr, xV, fsV, yV, xTs, fsTs, yTs, mn, mx, model, en

def prn(o, e, mim, flag):
	e=e; e[e<0]=0
	if flag==1:
		for i in range(o.shape[0]):
			rmse=np.sqrt(np.mean(np.square(o[i]-e[i]))); rmsePM=np.sqrt(np.mean(np.square(o[i]-mim[i])))
			print ("rmse ", i, rmse, rmsePM)
	if flag==0:
		_n=55
		p=e[_n][0]; r=o[_n][0]; mm=mim[_n][0]
		for tup, v in np.ndenumerate(r):
			if p[tup]!=0 or r[tup]!=0:
				print (p[tup], "_____", r[tup], "_______", mm[tup])
			pass
	rmse=np.sqrt(np.mean(np.square(o-e))); rmsePM=np.sqrt(np.mean(np.square(o-mim)))
	print ("\n total rmse rmsePM ysum predsum ", rmse, rmsePM, o.sum(), e.sum())
	return rmse, rmsePM

def eval(model, x, y, mx, mn):
	pred=model.predict(x)
	pred=pred*(mx-mn)+mn; pred=rnd(pred)
	y=y*(mx-mn)+mn; y=rnd(y)
	rmse=np.sqrt(np.mean(np.square(y-pred)))
	return rmse, pred

def trainTest():
	
	global Hwnd; global Pwnd; global dim

	#getting data and models
	x, fs, y, xV, fsV, yV, xTs, fsTs, yTs, mn, mx, model, en=getFiles_n_Model()

	#train-test
	epochs=100; batch_size=32; saveModel=op+"favardModel"+ntw+".h5"

	dfStats=pd.DataFrame(columns=["loss", "acc", "val_loss", "val_acc"]); ep=0
	for e in range(epochs):
		#his=model.fit([x, fs], [y], validation_data=([xV, fsV], [yV]), epochs=1, batch_size=batch_size, verbose=2)
		his=model.fit([x, fs], [y], epochs=1, batch_size=batch_size, verbose=2)
		val_loss=model.evaluate([xV, fsV], [yV])
		dfStats.loc[len(dfStats)]=[his.history["loss"][0], his.history["accuracy"][0], val_loss[0], val_loss[1]]
		ep=e
		#if math.isnan(his.history["loss"][0]) or math.isnan(val_loss[0]):
		#	break
	dfStats.to_csv(op+"dfStats"+ntw+"_"+str(Hwnd)+"_"+str(Pwnd)+".csv", index=False)
	#print (dfStats)

	#creating a dictionary for results
	resD=dict()

	#save and load model
	en.saveModel(model, saveModel)
	model=en.loadModel(saveModel)

	#prediction testing
	pred=model.predict([xTs, fsTs], verbose=0)
	#pred[~np.isfinite(pred)]=0; mx[mx==0]=1
	print ("sum before pred y ", pred.sum(), yTs.sum())
	resD["pred_sum_0"]=pred.sum(); resD["y_sum_0"]=yTs.sum()

	mim=np.zeros(pred.shape)	
	pred=pred*(mx-mn)+mn; pred=rnd(pred); mim=mim*(mx-mn)+mn#; print ("********", np.isnan(pred).any(), pred.sum())
	resD["PM_sum"]=mim.sum(); resD["pred_sum"]=pred.sum(); resD["y_sum"]=yTs.sum()
	yTs=yTs*(mx-mn)+mn; yTs=rnd(yTs)
	rmse, rmsePM=np.sqrt(np.mean(np.square(yTs-pred))), np.sqrt(np.mean(np.square(yTs-mim)))
	print ("predsum, ysum mimsum rmse rmsePM ", type(pred), pred.shape, np.isnan(pred).any(), pred.sum(), yTs.sum(), mim.sum(), rmse, rmsePM)
	prn(yTs, pred, mim, 0)
	resD["rmse"]=rmse; resD["rmsePM"]=rmsePM

	np.save("repo/"+ntw+"/pred"+str(Hwnd)+"_"+str(Pwnd)+"_"+str(dim), pred)
	if dim==5:
		np.save("repo/"+ntw+"/real"+str(Hwnd)+"_"+str(Pwnd)+"_"+str(dim), yTs)

	#mape
	deno=copy.deepcopy(pred); deno[deno<=0]=1
	mape=np.mean(np.abs(np.divide(yTs-pred, deno)))

	#smape
	deno=np.abs(yTs)+np.abs(pred); deno=deno/2; deno=copy.deepcopy(deno); deno[deno<=0]=1
	smape=np.mean(np.divide(np.abs(yTs-pred), deno))

	f=open(op+"res"+ntw+".pkl", "wb")
	pickle.dump(resD, f)
	f.close()

	##saving results into a csv dataframe
	dfRes=0
	if not os.path.exists(op+"res"+ntw+".csv"):
		dfRes=pd.DataFrame(columns=["Hwnd", "Pwnd", "dim", "rmse", "mape", "smape", "epochs"])
		dfRes.to_csv(op+"res"+ntw+".csv", index=False)
	dfRes=pd.read_csv(op+"res"+ntw+".csv")
	dfRes.loc[len(dfRes)]=[Hwnd, Pwnd, dim, rmse, mape, smape, ep+1]	
	dfRes.to_csv(op+"res"+ntw+".csv", index=False)
	del model
	K.clear_session()	

	return

trainTest()
