python -W ignore getRunTHS.py 24 12 5
python -W ignore getRunTHS.py 24 12 10 
python -W ignore getRunTHS.py 24 12 20
python -W ignore getRunTHS.py 24 12 40
python -W ignore getRunTHS.py 24 12 70
python -W ignore getRunTHS.py 24 12 100
python -W ignore getRunTHS.py 24 12 120
python -W ignore getRunTHS.py 10 12 5
python -W ignore getRunTHS.py 10 12 10 
python -W ignore getRunTHS.py 10 12 20
python -W ignore getRunTHS.py 10 12 40
python -W ignore getRunTHS.py 10 12 70
python -W ignore getRunTHS.py 10 12 100
python -W ignore getRunTHS.py 10 12 120

