#import os
#os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID" 
#os.environ["CUDA_VISIBLE_DEVICES"] = "2"

import os
os.environ['PYTHONHASHSEED'] = '0'
os.environ['KERAS_BACKEND'] = 'tensorflow'
#os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import random
random.seed(0)
import numpy as np
np.random.seed(0)
import tensorflow as tf
from tensorflow import set_random_seed
set_random_seed(1)

import sys
import pandas as pd
#import numpy as np
#np.random.seed(0)
import keras
from keras.layers import Layer
import keras.backend as K
#import tensorflow as tf
from keras.utils import plot_model
from keras.models import Model
from keras import Input#, Model
from keras.optimizers import Adam
from keras.regularizers import l2
from keras.layers import Flatten, Dense, Lambda, LSTM, Reshape, TimeDistributed, Dropout, BatchNormalization, Concatenate, Reshape
from keras.models import load_model
from keras.optimizers import Adam
from keras.layers import Bidirectional

from HOGCN import HoGCN 
from FAVARD import Favard
from APPROX import Approx

opt = Adam(lr=0.0001)
keras.regularizers.l1(0.)
keras.regularizers.l2(0.)
keras.regularizers.l1_l2(l1=0.01, l2=0.01)

def l1_reg(weight_matrix):
    return 0.00001 * K.sum(K.abs(weight_matrix))



class Encoder:
	
	def __init__(self):
		print ("Encoder Class is instantiated.")

	def _proc(self):
		print ("proctected scope")

	def demo(self):
		print ("public scope method")

	def vectorizer(self, x, last_dim):
		sp=x.get_shape().as_list()
		print (type(sp), sp, type(last_dim), last_dim)
		#sp=x.get_shape().as_list()
		if sp[-1]==last_dim:
			b, t, n1, n2=x.get_shape().as_list()	
			x=tf.reshape(x, [-1, t, n1*n2])
			print ("lambda inside ", x.shape)
		return x##unable to return list ??

	def enDe(self, **kwargs):
		#all inputs
		batch=kwargs["batch"]
		A=kwargs["A"]
		X=kwargs["X"]
		k_depth=kwargs["k_depth"]
		d_dim=kwargs["d_dim"]
		pwnd=kwargs["pwnd"]
		T_k=kwargs["T_k"]

		#model
		vis_A=Input(batch_shape=(batch, )+A)
		vis_X=Input(batch_shape=(batch, )+X)
		
		s=HoGCN(d_dim, k_depth=k_depth, kernel_regularizer=l1_reg, bias_regularizer=l1_reg, use_bias=True)([vis_A, vis_X])
		b, t, n1, n2=s.get_shape().as_list()
		s=Lambda(lambda x:tf.reshape(x, [-1, t, n1*n2]))(s)##best reshaping method, need batch also using -1
		s=LSTM(n1*n2, return_sequences=False, dropout=0.5, recurrent_dropout=0.3)(s)
		#s=BatchNormalization()(s)
		s=Lambda(lambda x:tf.reshape(x, [-1, n1, n2]))(s)

		s_fav=Favard(depth=T_k, kernel_regularizer="l1")(s)
		s_approx=Approx(pwnd)([s, s_fav])

		model=Model([vis_A, vis_X], [s_approx])
		
		model.compile(optimizer=opt, loss="mean_squared_error", metrics=['accuracy'])
		# summarize layers
		#print(model.summary())
		# plot graph
		plot_model(model, to_file='repo/enDe.png')

		return model	

	def saveModel(self, model, saveModel):
		model.save(saveModel)
		return model

	def loadModel(self, saveModel):
		model=load_model(saveModel, custom_objects={"tf":tf, "HoGCN":HoGCN, "Favard":Favard, "Approx":Approx})
		return model	
		

	
#keras each layer and input output can be obtained from the model variable. Each layer has many weights. The list of weights can be obtained for a layer by
# layer.get_weights():- list; inside the list their are numpy/tensor array of weights; the first one is (input X output) shape, second is bias etc.
def prog():
	#temporal sequence
	samples=256; batch=32
	N=24
	#nodes, features dim
	n=55; f=5; d_dim=10; k_depth=2; pwnd=4; T_k=20
	kwargs={"batch":batch, "A":(N, n, n), "X":(N, n, f), "d_dim":d_dim, "k_depth":k_depth, "pwnd":pwnd, "T_k":T_k}
	en=Encoder()

	model=en.enDe(**kwargs)
	
	#data
	odmTr=np.random.uniform(low=0, high=100, size=(samples, N, n, n)).astype(int)
	featuresTr=np.random.uniform(low=0, high=100, size=(samples, N, n, f)).astype(int)
	yTr=np.random.uniform(low=0, high=100, size=(samples, pwnd, n, n)).astype(int)
	odmTs=odmTr[-32:]; featuresTs=featuresTr[-32:]; yTs=yTr[-32:]
	odmTr=odmTr[:-32]; featuresTr=featuresTr[:-32]; yTr=yTr[:-32]
	print (odmTr.shape, featuresTr.shape, yTr.shape, odmTs.shape, featuresTs.shape, yTs.shape)

	history=model.fit([odmTr, featuresTr], [yTr], verbose=1, epochs=1, batch_size=batch)
	yPred=model.predict([odmTs, featuresTs], batch_size=batch)
	print (type(yPred), yPred.shape)
	return

#prog()
