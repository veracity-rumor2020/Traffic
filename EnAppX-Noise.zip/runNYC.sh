python -W ignore getRunNYC.py 24 12 5
python -W ignore getRunNYC.py 24 12 10
python -W ignore getRunNYC.py 24 12 20
python -W ignore getRunNYC.py 24 12 30
python -W ignore getRunNYC.py 24 12 40
python -W ignore getRunNYC.py 24 12 50
