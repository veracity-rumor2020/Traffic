import keras
from keras import backend as K
from keras.layers import Layer
import tensorflow as tf
from keras import activations, initializers, constraints

class HoGCN(Layer):

	def __init__(self, output_dim=None, k_depth=None, kernel_initializer='glorot_uniform', kernel_regularizer=None, kernel_constraint=None, use_bias=True, bias_initializer='zeros', bias_regularizer=None, bias_constraint=None,**kwargs):
		self.output_dim = output_dim
		self.k_depth=k_depth
		self.kernel_initializer = keras.initializers.get(kernel_initializer)
		self.kernel_regularizer = keras.regularizers.get(kernel_regularizer)
		self.kernel_constraint = keras.constraints.get(kernel_constraint)
		self.use_bias = use_bias
		self.bias_initializer = keras.initializers.get(bias_initializer)
		self.bias_regularizer = keras.regularizers.get(bias_regularizer)
		self.bias_constraint = keras.constraints.get(bias_constraint)
		self.kernel, self.b = None, None
		super(HoGCN, self).__init__(**kwargs)

	def build(self, input_shape):
		assert isinstance(input_shape, list)
		# Create a trainable weight variable for this layer.
		self.kernel = self.add_weight(name='kernel', shape=(input_shape[1][3], self.output_dim), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		if self.use_bias:
			self.b = self.add_weight(shape=(self.output_dim,), initializer=self.bias_initializer, regularizer=self.bias_regularizer, constraint=self.bias_constraint, name='{}_b'.format(self.name),)
		super(HoGCN, self).build(input_shape)  # Be sure to call this at the end

	def call(self, x):
		assert isinstance(x, list)
		A, H= x
		out=tf.matmul(A, H); x3d=out.get_shape().as_list() 
		out=tf.matmul(out, self.kernel); x3d=out.get_shape().as_list() 
		if self.use_bias:
			out+= self.b
		out=keras.activations.relu(out, alpha=0.0, max_value=None, threshold=0.0)
		return out

	def get_config(self):
		config = super(HoGCN, self).get_config()
		config.update({"output_dim": self.output_dim, "k_depth":self.k_depth})
		return config

	def compute_output_shape(self, input_shape):
		assert isinstance(input_shape, list)
		shape_a, shape_b= input_shape
		#print (shape_a[:-1]+(self.output_dim,)); input("enter")
		return [shape_a[:-1]+(self.output_dim,)]#[(shape_a[:-1], self.output_dim)]
		###this is important return only exact output shape this custom layer is sending including dim for batch as None or ? 
