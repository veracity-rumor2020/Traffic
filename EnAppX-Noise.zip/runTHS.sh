python -W ignore getRunTHS.py 24 12 40
python -W ignore getRunTHS.py 24 12 50
python -W ignore getRunTHS.py 24 12 5
python -W ignore getRunTHS.py 24 12 10
python -W ignore getRunTHS.py 24 12 20
python -W ignore getRunTHS.py 24 12 30
