import keras
from keras import backend as K
from keras.layers import Layer
import tensorflow as tf
from keras import activations, initializers, constraints

class Favard(Layer):

	def __init__(self, depth=None, kernel_initializer='glorot_uniform', kernel_regularizer=None, kernel_constraint=None, use_bias=True, bias_initializer='zeros', bias_regularizer=None, bias_constraint=None,**kwargs):
		self.depth=depth
		self.kernel_initializer = keras.initializers.get(kernel_initializer)
		self.kernel_regularizer = keras.regularizers.get(kernel_regularizer)
		self.kernel_constraint = keras.constraints.get(kernel_constraint)
		self.use_bias = use_bias
		self.bias_initializer = keras.initializers.get(bias_initializer)
		self.bias_regularizer = keras.regularizers.get(bias_regularizer)
		self.bias_constraint = keras.constraints.get(bias_constraint)
		self.kernel, self.b = None, None
		super(Favard, self).__init__(**kwargs)

	def build(self, input_shape):
		assert isinstance(input_shape, tuple)
		# Create a trainable weight variable for this layer.
		a, _, c=input_shape
		self.kernel = self.add_weight(name='kernel', shape=(c, c), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		#self.c = self.add_weight(name='kernel', shape=(c, c), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		#self.d = self.add_weight(name='kernel', shape=(c, c), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		if self.use_bias:
			self.b = self.add_weight(shape=(c, c), initializer=self.bias_initializer, regularizer=self.bias_regularizer, constraint=self.bias_constraint, name='{}_b'.format(self.name),)
		super(Favard, self).build(input_shape)  # Be sure to call this at the end

	def call(self, x):
		#assert isinstance(x, list)##why x is assumed to be a list?
		#x=x[0]
		a, b, c=x.shape
		x=tf.matmul(x, x, transpose_a=True)
		x=tf.matmul(x, self.kernel)
		x=tf.tanh(x)
		lis=[tf.ones(tf.shape(x)), x]##activation tanh missing
		
		def rec(T_b, T_a, x):
			x_=tf.multiply(x, 2.0)
			return tf.matmul(x_, T_b)-T_a

		for i in range(self.depth-2):
			lis.append(rec(lis[-1], lis[-2], x))

		out=tf.stack(lis, axis=1)

		if self.use_bias:
			out+= self.b	
		out=tf.sigmoid(out)	
		return out#[K.dot(a, self.kernel) + b, K.mean(b, axis=-1)]

	def get_config(self):
		config = super(Favard, self).get_config()
		config.update({"depth": self.depth})
		return config

	def compute_output_shape(self, input_shape):
		a, b, c= input_shape
		return [(input_shape[0], self.depth, c, c)]
		###this is important return only exact output shape this custom layer is sending including dim for batch as None or ? 
