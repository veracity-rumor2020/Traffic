import keras
from keras import backend as K
from keras.layers import Layer
import tensorflow as tf
from keras import activations, initializers, constraints

class Approx(Layer):

	def __init__(self, out_N=None, kernel_initializer='glorot_uniform', kernel_regularizer=None, kernel_constraint=None, use_bias=True, bias_initializer='zeros', bias_regularizer=None, bias_constraint=None,**kwargs):
		self.out_N=out_N
		self.kernel_initializer = keras.initializers.get(kernel_initializer)
		self.kernel_regularizer = keras.regularizers.get(kernel_regularizer)
		self.kernel_constraint = keras.constraints.get(kernel_constraint)
		self.use_bias = use_bias
		self.bias_initializer = keras.initializers.get(bias_initializer)
		self.bias_regularizer = keras.regularizers.get(bias_regularizer)
		self.bias_constraint = keras.constraints.get(bias_constraint)
		self.kernel, self.b = None, None
		super(Approx, self).__init__(**kwargs)

	def build(self, input_shape):
		assert isinstance(input_shape, list)
		_, n, _=input_shape[0]
		_, t, _, d=input_shape[1]
		# Create a trainable weight variable for this layer.
		self.kernel = self.add_weight(name='kernel', shape=(t, d), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		self.kernel_D = self.add_weight(name='kernel', shape=(self.out_N, d, d), initializer='uniform', trainable=True, regularizer=self.kernel_regularizer, constraint=self.kernel_constraint)
		if self.use_bias:
			self.b = self.add_weight(shape=(self.out_N, n, n), initializer=self.bias_initializer, regularizer=self.bias_regularizer, constraint=self.bias_constraint, name='{}_b'.format(self.name),)
		super(Approx, self).build(input_shape)  # Be sure to call this at the end

	def call(self, x):
		assert isinstance(x, list)
		F, T=x[0], x[1]
		bt, n, d=F.get_shape().as_list()
		_, t, _, _=T.get_shape().as_list()
		T=tf.reshape(T, (t, bt, d, d))
		out=tf.matmul(F, T) 
		out_act=tf.sigmoid(tf.multiply(out, out)); out=tf.multiply(out_act, out)
		out=tf.reshape(out, (bt, n, d, t))
		out=tf.matmul(out, self.kernel)
		out=tf.reduce_sum(out, 3)
		lis=[out for i in range(self.out_N)]
		out=tf.stack(lis, axis=1)
		out=tf.matmul(out, self.kernel_D)
		out=tf.matmul(out, out, transpose_b=True)
		if self.use_bias:
			out+= self.b
		#out=tf.nn.sigmoid(out)
		out=tf.nn.relu(out)
		return out

	def get_config(self):
		config = super(Approx, self).get_config()
		config.update({"out_N": self.out_N})
		return config

	def compute_output_shape(self, input_shape):
		assert isinstance(input_shape, list)
		b, n, d=input_shape[0]
		return [(b, self.out_N, n, n)]#[(shape_a[:-1], self.output_dim)]
		###this is important return only exact output shape this custom layer is sending including dim for batch as None or ? 
